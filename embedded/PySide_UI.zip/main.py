from PySide6.QtWidgets import *
from PySide6.QtCore import *
from go_ui import Ui_Form

class MyApp(QWidget,Ui_Form):
    def __int__(self):
        super().__init__()
        self.main()

    def main(self):
        self.pb.setValue(0)
        self.tm = QTimer()
        self.tm.setInterval(10)
        self.tm.timeout.connect(self.run)

    def run(self):
        if self.pb.value() == 100:
            self.tm.stop()
        self.pb.setValue(self.pb.value() + 1)

    def go(self):
        if self.tm.isActive() == False:
            self.tm.start()

    def pause(self):
        if self.tm.isActive() == True:
            self.tm.stop()

    def stop(self):
        self.pb.setValue(0)

app = QApplication()
win = MyApp()
win.show()
app.exec()